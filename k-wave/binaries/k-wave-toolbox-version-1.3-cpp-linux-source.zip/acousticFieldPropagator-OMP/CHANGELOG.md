# Changelog

## Version 1.0 (28 February 2020) – kWave release 1.3
  - Initial public release
